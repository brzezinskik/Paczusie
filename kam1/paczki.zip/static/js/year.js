function year(){
    document.getElementById("year").innerHTML = new Date().getFullYear();
}
year()

